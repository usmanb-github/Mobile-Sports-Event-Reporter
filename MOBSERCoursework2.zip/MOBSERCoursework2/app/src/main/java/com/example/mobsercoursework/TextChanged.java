package com.example.mobsercoursework;

import android.text.Editable;
import android.text.TextWatcher;

abstract class TextChanged implements TextWatcher {
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        return;
    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        return;
    }

    @Override
    public void afterTextChanged(Editable editable) {
        return;
    }
}
