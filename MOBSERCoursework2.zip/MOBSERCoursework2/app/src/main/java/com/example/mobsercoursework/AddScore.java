package com.example.mobsercoursework;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AddScore extends AppCompatActivity {

    DatabaseSingleton db;
    ArrayAdapter<String> adapterList;
    Spinner spinner;
    List<String> list;
    Button button;
    EditText score1, score2;
    TextView scoreView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_score_activity);
        db = DatabaseSingleton.getInstance(this);
        spinner = findViewById(R.id.spinnerID);
        list = new ArrayList<>();
        button = findViewById(R.id.addScoreButton);
        score1 = findViewById(R.id.editTextScore1);
        score2 = findViewById(R.id.editTextScore2);
        scoreView = findViewById(R.id.scoreTextView);

        getSpinnerData();
        viewData(getID());
        getAddScoreData();
    }

    public void getAddScoreData() {
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                viewData(getID());

                if (getScore1() == 'n' && getScore2() == 'l') {
                    score1.setText("0");
                    score2.setText("0");
                    scoreView.setText("Current score: No data shown. Please add score");
                } else {
                    score1.setText(String.copyValueOf(new char[]{getScore1()}));
                    score2.setText(String.copyValueOf(new char[]{getScore2()}));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Model.setMessage("Successfully updated score", AddScore.this).show();
                String score = Integer.parseInt(score1.getText().toString()) + "-" + Integer.parseInt(score2.getText().toString());
                db.updateScore(getID(), score);
                viewData(getID());
            }
        });
    }

    public void getSpinnerData() {
        Cursor cursorListID = db.getAllID();
        if (cursorListID.getCount() == 0) {
            Model.setMessage("No data shown", AddScore.this).show();
        } else {
            while (cursorListID.moveToNext()) {
                list.add(cursorListID.getString(0) + ")" + " " + cursorListID.getString(4));
                scoreView.setText("Current score:" + " " + cursorListID.getString(9));
            }
        }
        adapterList = new ArrayAdapter<String>
                (AddScore.this, android.R.layout.simple_spinner_item, list);
        adapterList.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterList);
    }

    public int getID() {
        if (spinner.getCount() == 0) {
            Model.setMessage("No data shown", AddScore.this).show();
        } else {
            String id = spinner.getSelectedItem().toString(); //here getting all of the text spinner.
            String[] parts = id.split("\\)"); // gets all info and splits at ) part.
            int beforeFirstDot = Integer.parseInt(parts[0]); //adding all of the integers into an int array.
            return beforeFirstDot; //returning int id
        }
        return -1;
    }

    public void viewData(int id) {
        Cursor cursorListID = db.getSpecificID(id);
        while (cursorListID.moveToNext()) {
            scoreView.setText("Current score:" + " " + cursorListID.getString(9));
        }
    }


    public char getScore1() {
        String score = scoreView.getText().toString();
        char result = score.charAt(15);
        return result;
    }

    public char getScore2() {
        String score = scoreView.getText().toString();
        char result = score.charAt(17);
        return result;
    }
}
