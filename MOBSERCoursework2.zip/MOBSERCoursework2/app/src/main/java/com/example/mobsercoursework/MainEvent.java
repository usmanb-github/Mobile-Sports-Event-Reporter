package com.example.mobsercoursework;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainEvent extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_event_activity);
        getMainData();
    }

    public void getMainData(){
        Button addEvent = (Button) findViewById(R.id.addEventReview);
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(MainEvent.this, AddEvent.class);
                startActivity(intent);
            }
        });
        Button editEvent = (Button) findViewById(R.id.editEventButton);
        editEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(MainEvent.this, ViewEvent.class);
                startActivity(intent);
            }
        });

        Button addScoreEvent = (Button) findViewById(R.id.addScoreButton);
        addScoreEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(MainEvent.this, AddScore.class);
                startActivity(intent);
            }
        });
        Button searchEvent = (Button) findViewById(R.id.searchButton);
        searchEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(MainEvent.this, SearchEvent.class);
                startActivity(intent);
            }
        });

        final Button phoneGapButton = (Button) findViewById(R.id.phoneGapButton);
        phoneGapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WebView wb = new WebView(MainEvent.this);
                wb.loadUrl("http://172.16.171.38:3000/");
                setContentView(wb);
            }
        });
    }
}
