package com.example.mobsercoursework;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.List;

public class ViewEvent extends AppCompatActivity {

    DatabaseSingleton db;
    GridView gridView;
    ArrayList<String> theList = new ArrayList<String>();
    List<String> list;
    TextView textView2;
    ListAdapter listAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_event_activity);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        db = DatabaseSingleton.getInstance(this);
        list = new ArrayList<>();
        gridView = (GridView) findViewById(R.id.listView);
        textView2 = findViewById(R.id.textView2);
        viewData();
        getGridViewData();
    }

    public void getGridViewData(){
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final AdapterView<?> adapterView, final View view, final int position, final long ID) {
                gridView.setItemChecked(position, true);
                final String s = adapterView.getItemAtPosition((int) ID).toString();
                textView2.setText(s);
                AlertDialog.Builder alert = new AlertDialog.Builder(ViewEvent.this);
                alert.create();
                alert.setMessage("Do you want to continue to edit this event?");
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                alert.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String finalRes = textView2.getText().toString();
                        String[] parts = finalRes.split("\\)"); // String array, each element is text between dots
                        int result = Integer.parseInt(parts[0]);
                        Intent intent = new Intent(ViewEvent.this, EditEvent.class);
                        intent.putExtra("IDPassed", result);
                        startActivity(intent);
                    }
                });
                alert.show();
            }
        });
    }

    public void viewData() {
        final Cursor data = db.getAllID();
        if(gridView.getCount() == -1) {
            theList.add("No data here.");
        } else {
            while (data.moveToNext()) {
                theList.add(data.getString(0) + ")" + " " +
                        "Date: " + data.getString(1) + " " +
                        "Time: " + data.getString(2) + " " +
                        "Sport: " + data.getString(3) + " " +
                        "Teams: " + data.getString(4));
            }
        }
        listAdapter = new ArrayAdapter<String>(ViewEvent.this, android.R.layout.simple_list_item_1, theList);
        gridView.setAdapter(listAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deleteEvents:
                AlertDialog.Builder alert = new AlertDialog.Builder(ViewEvent.this);
                alert.create();
                alert.setTitle("Alert Message!");
                alert.setMessage("Are you sure you want to delete all of the information?");
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                alert.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        boolean deleteAll = db.deleteDataAll();
                        if (gridView.getCount() <= 0) {
                           Model.setMessage("No content added", ViewEvent.this).show();
                        } else if (deleteAll == true) {
                            Model.setMessage("All content cleared.", ViewEvent.this).show();
                            viewData();
                            theList.clear();
                        }
                    }
                });
                alert.show();
        }
        return super.onOptionsItemSelected(item);
    }
}
