package com.example.mobsercoursework;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.Toolbar;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SearchEvent extends AppCompatActivity {


    private SearchView searchEditText;
    DatabaseSingleton db;
    private ListView listView;
    ArrayAdapter<String> listAdapter;
    List<String> listString;
    Dialog dialog;
    DatePickerDialog datePickerDialog, datePickerDialog2;
    EditText editTextDate1, editTextDate2;
    Button button, button2;
    String sendData;
    String addResult = "";
    TextView text;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_event_activity);
        db = DatabaseSingleton.getInstance(this);
        listView = (ListView) findViewById(R.id.listView2);
        button2 = findViewById(R.id.button2);
        text = (TextView) findViewById(R.id.textView3);
        dialog = new Dialog(this);
        searchEditText = (SearchView) findViewById(R.id.searchField);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar1);
        setSupportActionBar(toolbar);
        listString = new ArrayList<String>();
        listAdapter = new ArrayAdapter<String>(SearchEvent.this, android.R.layout.simple_list_item_1, listString);
        listView.setAdapter(listAdapter);
        getSearchEventData();
    }

    public void getSearchEventData() {
        Model.setMessageLong("Please use date range image for selection of specific dates to view", SearchEvent.this).show();

        Cursor data = db.getAllID();
        while (data.moveToNext()) {
            listString.add(data.getString(0) + "]" + " " + data.getString(4));
        }
        listAdapter = new ArrayAdapter<String>(SearchEvent.this, android.R.layout.simple_list_item_1, listString);
        listView.setAdapter(listAdapter);

        searchEditText.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                (SearchEvent.this).listAdapter.getFilter().filter(s);
                return false;
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listString.size() > 0) {
                    String fullResult = "";
                    int i = 0;
                    int getListSize = listString.size();
                    --getListSize;

                    for (i = 0; i < getListSize; i++) {
                        fullResult += "{\"name\":\"" + listString.get(i) + "\"},";
                    }
                    addResult = "{\"name\":\"" + listString.get(i) + "\"}";
                    fullResult += addResult;

                    sendData ="{\"userId\":\"ub2232e\", \"detailList\":["   + fullResult + "]}";

                    Intent SendJson = new Intent(SearchEvent.this, JSONParse.class);
                    SendJson.putExtra("json", sendData);
                    SendJson.putExtra("result", fullResult);
                    startActivity(SendJson);
                } else {
                    Model.setMessage("No data", SearchEvent.this).show();
                }
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String text1 = (String) adapterView.getItemAtPosition(i);
                String[] parts = text1.split("]");
                int result = Integer.parseInt(parts[0]);

                AlertDialog.Builder alert = new AlertDialog.Builder(SearchEvent.this);
                alert.create();
                final Cursor data = db.getSpecificID(result);

                while (data.moveToNext()) {
                    alert.setMessage("ID: " + data.getString(0) + " " +
                            "\nDate: " + data.getString(1) + " " +
                            "\nTime: " + data.getString(2) + " " +
                            "\nSport: " + data.getString(3) + " " +
                            "\nTeams: " + data.getString(4) + " " +
                            "\nLocation: " + data.getString(5) + " " +
                            "\nEmail: " + data.getString(6) + " " +
                            "\nComment: " + data.getString(7) + " " +
                            "\nPrediction: " + data.getString(8)
                    );
                }
                Model.setMessage("Please click elsewhere for exit", SearchEvent.this).show();
                alert.show();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        ActionMenuItemView f = (ActionMenuItemView) findViewById(R.id.search);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPopUp();
            }
        });
        return super.onOptionsItemSelected(item);
    }

    public void ShowPopUp() {
        dialog.setContentView(R.layout.pop_up_window);
        editTextDate1 = dialog.findViewById(R.id.editTextOne);
        editTextDate2 = dialog.findViewById(R.id.editTextTwo);
        button = (Button) dialog.findViewById(R.id.button);

        editTextDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog = getDate(editTextDate1);
                datePickerDialog.show();
                editTextDate1.setError(null);
            }
        });

        editTextDate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog2 = getDate(editTextDate2);
                datePickerDialog2.show();
                editTextDate2.setError(null);
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(editTextDate1.getText().toString())) {
                    Model.setMessage("Date is empty.", SearchEvent.this).show();
                    editTextDate1.setError("Empty");
                } else if (TextUtils.isEmpty(editTextDate2.getText().toString())) {
                    Model.setMessage("Date is empty.", SearchEvent.this).show();
                    editTextDate2.setError("Empty");

                } else {
                    listAdapter.clear(); // clears to prevent duplication entry in list view
                    String dateText = editTextDate1.getText().toString();
                    String dateText1 = editTextDate2.getText().toString();

                    Cursor data = db.getSearchName(dateText, dateText1);

                    while (data.moveToNext()) {
                        listString.add(data.getString(0) + "]" + " " + data.getString(4));
                    }
                    dialog.dismiss();
                }
            }
        });
        dialog.show();
    }

    public DatePickerDialog getDate(final EditText date) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        date.setText(day + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
        return dialog;
    }
}
//Start Maps
