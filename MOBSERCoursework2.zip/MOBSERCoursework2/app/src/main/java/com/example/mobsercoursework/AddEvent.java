package com.example.mobsercoursework;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.regex.Matcher;

public class AddEvent extends AppCompatActivity {


    private static final String TAG = "AddEvent";
    private DatePicker dateReview;
    private Spinner spinnerSport;
    private DatePickerDialog datePickerDialog;
    private TimePickerDialog.OnTimeSetListener timeSetListener;
    private EditText editTextDate;
    private EditText editTextTime;
    private EditText editTextTeams;
    private EditText editTextLocation;
    private EditText editTextEmail;
    private EditText editTextComment;
    private EditText editTextPrediction;
    private Button addEvent;
    private String date;
    ArrayAdapter<String> adapterSport;
    DatabaseSingleton db;
    ImageButton maps, searchMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event_activity);
        db = DatabaseSingleton.getInstance(this);
        editTextDate = (EditText) findViewById(R.id.editTextDate);
        editTextTime = (EditText) findViewById(R.id.editTextTime);
        spinnerSport = (Spinner) findViewById(R.id.spinnerSport);
        editTextTeams = (EditText) findViewById(R.id.editTextPlayed);
        editTextLocation = (EditText) findViewById(R.id.editTextLocation);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextComment = (EditText) findViewById(R.id.editTextComment);
        editTextPrediction = (EditText) findViewById(R.id.editTextPrediction);
        addEvent = (Button) findViewById(R.id.addEvent);
        maps = (ImageButton) findViewById(R.id.imageButton);
        searchMap = (ImageButton) findViewById(R.id.imageButton2);
        getAddEventData();
    }


    public void getAddEventData() {
        adapterSport = new ArrayAdapter<String>(AddEvent.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.list));
        adapterSport.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSport.setAdapter(adapterSport);
        editTextDate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(AddEvent.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                editTextDate.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, day);
                datePickerDialog.show();
                editTextDate.setError(null);
            }
        });

        editTextTime.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int hour = cal.get(Calendar.HOUR);
                int minute = cal.get(Calendar.MINUTE);
                Log.d(TAG, "" + hour + minute);

                TimePickerDialog timeDialog = new TimePickerDialog(AddEvent.this, timeSetListener,
                        hour, minute, true);
                timeDialog.setTitle("Select Time");
                timeDialog.show();
            }
        });
        timeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                if (minute == 0 || minute == 1 || minute == 2 ||
                        minute == 3 || minute == 4 || minute == 5 ||
                        minute == 6 || minute == 7 || minute == 8 || minute == 9) {
                    editTextTime.setText(hourOfDay + ":0" + minute);
                    editTextTime.setError(null);
                } else {
                    editTextTime.setText(hourOfDay + ":" + minute);
                    editTextTime.setError(null);
                }
            }
        };
        editTextTeams.addTextChangedListener(new TextChanged() {
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                getStringValidationTeams();
            }
        });
        editTextComment.addTextChangedListener(new TextChanged() {
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                getStringValidationComment();
            }
        });
        editTextLocation.addTextChangedListener(new TextChanged() {
        @Override
        public void onTextChanged (CharSequence charSequence,int i, int i1, int i2){
            getStringValidationLocation();
            }
        });
        editTextEmail.addTextChangedListener(new TextChanged() {
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                getValidationEmail();
            }
        });

        editTextPrediction.addTextChangedListener(new TextChanged() {
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                getStringValidationPrediction();
            }
        });

        addEvent.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getValidation() == false) {
                    Model.setMessage("Please confirm the review", AddEvent.this).show();
                    getMessage();
                }
            }
        });

        maps.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddEvent.this, CurrentLocation.class);
                startActivity(intent);
            }
        });

        searchMap.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editTextLocation.getText().toString().isEmpty()) {
                   Model.setMessage("Please enter location to view this in the map", AddEvent.this).show();
                } else {
                    Intent intent = new Intent(AddEvent.this, SearchLocation.class);
                    intent.putExtra("location", editTextLocation.getText().toString());
                    startActivity(intent);
                }
            }
        });
    }

    private Boolean getValidation() {
        if (TextUtils.isEmpty(editTextDate.getText())) {
            editTextDate.setError("Required!");
            return true;
        } else if (TextUtils.isEmpty(editTextTime.getText())) {
            editTextTime.setError("Required!");
            return true;
        } else if (TextUtils.isEmpty(editTextTeams.getText())) {
            editTextTeams.setError("Required!");
            return true;
        } else if (getStringValidationTeams() == false) {
            return true;
        }
        return false;
    }

    private boolean getStringValidationTeams() {
        Matcher matchTeams = Model.getPatternString().matcher(editTextTeams.getText().toString());
        if (TextUtils.isEmpty(editTextTeams.getText().toString())) {
            editTextTeams.setError(null);
            return false;
        } else if (!matchTeams.matches()) {
            editTextTeams.setError("Please enter valid information");
            return false;
        }
        return true;
    }

    private boolean getStringValidationLocation() {
        Matcher matchTeams = Model.getPatternStringLocation().matcher(editTextLocation.getText().toString());
        if (TextUtils.isEmpty(editTextLocation.getText().toString())) {
            editTextLocation.setError(null);
            return false;
        } else if (!matchTeams.matches()) {
            editTextLocation.setError("Please enter valid information");
            return false;
        }
        return true;
    }

    private boolean getStringValidationComment() {
        Matcher matchTeams = Model.getPatternString().matcher(editTextComment.getText().toString());
        if (TextUtils.isEmpty(editTextComment.getText().toString())) {
            editTextComment.setError(null);
            return false;
        } else if (!matchTeams.matches()) {
            editTextComment.setError("Please enter valid information");
            return false;
        }
        return true;
    }

    private boolean getStringValidationPrediction() {
        Matcher matchTeams = Model.getPatternPrediction().matcher(editTextPrediction.getText().toString());
        if (TextUtils.isEmpty(editTextPrediction.getText().toString())) {
            editTextPrediction.setError(null);
            return false;
        } else  if (!matchTeams.matches()) {
            editTextPrediction.setError("Please enter valid information");
            return false;
        }
        return true;
    }

    private boolean getValidationEmail() {
        Matcher matchTeams = Model.getPatternEmail().matcher(editTextEmail.getText().toString());
        if (TextUtils.isEmpty(editTextEmail.getText().toString())) {
            editTextEmail.setError(null);
            return false;
        } else if (!matchTeams.matches()) {
            editTextEmail.setError("Please enter valid email");
            return false;
        }
        return true;
    }


    private String getConfirmationMessage() {
        return "Date: " + editTextDate.getText() + "\n" +
                "Time: " + editTextTime.getText() + "\n" +
                "Sport: " + spinnerSport.getSelectedItem() + "\n" +
                "Teams: " + editTextTeams.getText() + "\n" +
                "Location: " + editTextLocation.getText() + "\n" +
                "Email: " + editTextEmail.getText() + "\n" +
                "Comment: " + editTextComment.getText() + "\n" +
                "Prediction Score: " + editTextPrediction.getText() + "\n";
        //Give a rating out of 5 of your enjoyment of the game
    }

    private AlertDialog.Builder getMessage() {
        AlertDialog.Builder alert = new AlertDialog.Builder(AddEvent.this);
        alert.setTitle("Are you sure?");
        alert.setMessage(getConfirmationMessage());
        alert.setNegativeButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                      addData();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        alert.show();
        return alert;
    }

    public void addData() {
        boolean isInserted = db.insertData(editTextDate.getText().toString(), editTextTime.getText().toString(),
                spinnerSport.getSelectedItem().toString(),
                editTextTeams.getText().toString(), editTextLocation.getText().toString(),
                editTextEmail.getText().toString(),
                editTextComment.getText().toString(), editTextPrediction.getText().toString());
        if (isInserted == true) {
           Model.setMessage("Successfully added to the database", this).show();
        } else {
            Model.setMessage("Unsuccessfully added to database", this).show();
        }
    }
}