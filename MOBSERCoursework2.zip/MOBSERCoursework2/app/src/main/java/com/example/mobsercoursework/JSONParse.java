package com.example.mobsercoursework;

import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;


//Whole Class was used as a template from JSONDemo.zip. Taken from link below. Referenced in Report too.
//https://moodlecurrent.gre.ac.uk/mod/resource/view.php?id=942500
public class JSONParse extends AppCompatActivity {
    String JsonString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.json_parse_activity);
        WebView webView = (WebView) findViewById(R.id.webView);
        TextView textView = (TextView) findViewById(R.id.textView4);

        String jsonData = getIntent().getExtras().getString("json");
        String resultData = getIntent().getExtras().getString("result");
        String result = resultData;
        JsonString = jsonData;
        textView.setText("Here is was is being uploaded to the cloud successfully:- " + result);
        try {
            URL pageURL = new URL(getString(R.string.URLJSON));
            HttpURLConnection connection =
                    (HttpURLConnection) pageURL.openConnection();

            AsyncTask<String, Void, String> as = new PostAndDisplayTask(connection, webView);
            as.execute("jsonpayload", JsonString);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private String generatePage(String content) {
        return "<html><body><p>" + content + "</p></body></html>";
    }
    private class PostAndDisplayTask extends AsyncTask<String, Void, String> {

        private HttpURLConnection con;
        private WebView browser;


        public PostAndDisplayTask(HttpURLConnection con, WebView browser) {
            this.con = con;
            this.browser = browser;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            try {
                // configure the connection to do a POST
                con.setDoOutput(true);
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type",
                        "application/x-www-form-urlencoded");
            } catch (ProtocolException e) {
                e.printStackTrace();
            }
        }

        @TargetApi(Build.VERSION_CODES.KITKAT)
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected String doInBackground(String... params) {
            String postParameters = "";
            String response = "";
            try {
                postParameters = params[0] + "=" + URLEncoder.encode(params[1], "UTF-8");
                con.setFixedLengthStreamingMode(postParameters.getBytes().length);
                PrintWriter out = new PrintWriter(con.getOutputStream());
                out.print(postParameters);
                out.close();

                int responseCode = con.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    response = readStream(con.getInputStream());
                } else {
                    response = "Sorry error contacting server " + responseCode;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return response;
        }


        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            String page = generatePage(response);
            browser.loadData(page, "text/html", "UTF-8");
        }

        @TargetApi(Build.VERSION_CODES.KITKAT)
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        private String readStream(InputStream in) {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
                String nextLine = "";
                while ((nextLine = reader.readLine()) != null) {
                    sb.append(nextLine);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return sb.toString();
        }
    }
}

