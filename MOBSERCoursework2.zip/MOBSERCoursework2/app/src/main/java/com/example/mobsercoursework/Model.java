package com.example.mobsercoursework;


import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Pattern;

public  abstract class Model extends AppCompatActivity {


    public static Pattern getPatternStringLocation() {
        String patternString = "^[-,_a-zA-Z0-9.\\s*]+$";
        Pattern pattern = Pattern.compile(patternString);
        return pattern;
    }

    public static Pattern getPatternString() {
        String patternString = "^[-_a-zA-Z0-9.\\s*]+$";
        Pattern pattern = Pattern.compile(patternString);
        return pattern;
    }

    public static Pattern getPatternPrediction() {
        String patternString = "^[-0-9]+$";
        Pattern pattern = Pattern.compile(patternString);
        return pattern;
    }

    public static Pattern getPatternEmail() {
        String patternString = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
        Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
        return pattern;
    }

    public static Toast setMessage(String message, Context c) {
        Toast t = Toast.makeText(c, message, Toast.LENGTH_SHORT);
        return t;
    }

    public static Toast setMessageLong(String message, Context c) {
        Toast t = Toast.makeText(c, message, Toast.LENGTH_LONG);
        return t;
    }
}
