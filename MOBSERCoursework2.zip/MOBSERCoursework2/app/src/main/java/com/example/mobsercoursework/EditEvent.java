package com.example.mobsercoursework;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class EditEvent extends AppCompatActivity {
    DatabaseSingleton db;
    private Button editButton, deleteButton;
    private DatePickerDialog datePickerDialog;
    private TimePickerDialog timePickerDialog;
    private TimePickerDialog.OnTimeSetListener timeSetListener;
    private String idString, dateString, timeString, sportString, teamsString, locationString, emailString, commentString, predictionString;
    private EditText dateText, timeText, teamsText, locationText, emailText, commentText, predictionText;
    ArrayAdapter<String> adapterSport;
    private Spinner spinnerSport;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_event_activity);
        db = DatabaseSingleton.getInstance(this);

        spinnerSport = findViewById(R.id.spinnerSport);
        dateText = findViewById(R.id.editTextDate);
        timeText = findViewById(R.id.editTextTime);
        teamsText = findViewById(R.id.editTextPlayed);
        locationText = findViewById(R.id.editTextLocation);
        emailText = findViewById(R.id.editTextEmail);
        commentText = findViewById(R.id.editTextComment);
        predictionText = findViewById(R.id.editTextPrediction);
        editButton = findViewById(R.id.editEvent);
        deleteButton = findViewById(R.id.deleteButton);
        adapterSport = new ArrayAdapter<String>(EditEvent.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.list));
        adapterSport.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSport.setAdapter(adapterSport);

        getDetails();
    }


    public void getDetails() {
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Toast.makeText(EditEvent.this, "ID not selected. Please try again.", Toast.LENGTH_SHORT).show();
        } else {
            final int id = getIntent().getExtras().getInt("IDPassed");
            Cursor getData = (Cursor) db.getSpecificID(id);
            if (getData != null) {
                if (getData.moveToFirst()) {
                    idString = getData.getString(0);
                    dateString = getData.getString(1);
                    timeString = getData.getString(2);
                    sportString = getData.getString(3);
                    teamsString = getData.getString(4);
                    locationString = getData.getString(5);
                    emailString = getData.getString(6);
                    commentString = getData.getString(7);
                    predictionString = getData.getString(8);
                }
                dateText.setText(dateString);
                dateText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        datePickerDialog = getDate(dateText);
                        datePickerDialog.show();
                    }
                });
                timeText.setText(timeString);
                timeText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        timePickerDialog = getTime();
                        timePickerDialog.setTitle("Select Time");
                        timePickerDialog.show();
                    }
                });
                timeSetListener = getMinuteConfiguration(timeText);
                spinnerSport.setSelection(((ArrayAdapter<String>) spinnerSport.getAdapter()).getPosition(sportString));
                teamsText.setText(teamsString);
                locationText.setText(locationString);
                emailText.setText(emailString);
                commentText.setText(commentString);
                predictionText.setText(predictionString);
                editButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean resultUpdate = db.updateData(id, dateText.getText().toString(), timeText.getText().toString(), spinnerSport.getSelectedItem().toString(),
                                teamsText.getText().toString(), locationText.getText().toString(), emailText.getText().toString(), commentText.getText().toString(), predictionText.getText().toString());
                        if (resultUpdate == true) {
                            Model.setMessage("Successfully edited", EditEvent.this).show();
                            Intent intent = new Intent(EditEvent.this, ViewEvent.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(EditEvent.this, "false", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                deleteButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder alert = new AlertDialog.Builder(EditEvent.this);
                        alert.create();
                        alert.setTitle("Message Alert!");
                        alert.setMessage("Are you sure you want to delete event?");
                        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                        alert.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                db.deleteData(id);
                                Model.setMessage("Successfully deleted", EditEvent.this).show();
                                Intent intent = new Intent(EditEvent.this, ViewEvent.class);
                                startActivity(intent);
                            }
                        });
                        alert.show();
                    }
                });
            }
        }
    }

    public DatePickerDialog getDate(final EditText date) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        date.setText(day + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
        return dialog;
    }

    public TimePickerDialog getTime() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR);
        int minute = cal.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, timeSetListener,
                hour, minute, true);
        return timePickerDialog;
    }

    public TimePickerDialog.OnTimeSetListener getMinuteConfiguration(final EditText editTextTime) {
        return new TimePickerDialog.OnTimeSetListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                if (minute == 0 || minute == 1 || minute == 2 ||
                        minute == 3 || minute == 4 || minute == 5 ||
                        minute == 6 || minute == 7 || minute == 8 || minute == 9) {
                    editTextTime.setText(hourOfDay + ":0" + minute);
                    editTextTime.setError(null);
                } else {
                    editTextTime.setText(hourOfDay + ":" + minute);
                    editTextTime.setError(null);
                }
            }
        };
    }
}