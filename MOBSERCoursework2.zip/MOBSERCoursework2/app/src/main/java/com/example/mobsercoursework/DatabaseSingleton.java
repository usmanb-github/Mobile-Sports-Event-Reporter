package com.example.mobsercoursework;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseSingleton extends SQLiteOpenHelper {
    private static DatabaseSingleton mInstance = null;

    private static final String dbName = "Events.db";
    private static final String table = "addEvent";
    private static final String column1 = "ID";
    private static final String column2 = "DATE";
    private static final String column3 = "TIME";
    private static final String column4 = "SPORT";
    private static final String column5 = "TEAMS";
    private static final String column6 = "LOCATION";
    private static final String column7 = "EMAIL";
    private static final String column8 = "COMMENT";
    private static final String column9 = "PREDICTION";
    private static final String column10 = "ACTUALSCORE";

    public DatabaseSingleton(Context context) {
        super(context, dbName, null, 2);
        //private contructor to prevent others from others.
    }

    public static DatabaseSingleton getInstance(Context context) {
        if(mInstance == null) {
            return new DatabaseSingleton(context);
        }
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(" create table " + table + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "DATE TEXT, TIME TEXT, SPORT TEXT, TEAMS TEXT, " +
                "LOCATION TEXT, EMAIL TEXT, COMMENT TEXT, PREDICTION TEXT, ACTUALSCORE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + table);
        onCreate(db);
    }

    public Boolean insertData(String date, String time, String sport, String teams,
                              String location, String email, String comment,
                              String prediction) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(column2, date);
        contentValues.put(column3, time);
        contentValues.put(column4, sport);
        contentValues.put(column5, teams);
        contentValues.put(column6, location);
        contentValues.put(column7, email);
        contentValues.put(column8, comment);
        contentValues.put(column9, prediction);

        long result = db.insert(table, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor getAllID() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + table, null);
        return res;
    }

    public Cursor getSpecificID(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("select * from " + table + " where id =?", new String[]{String.valueOf(id)});
        return c;
    }

    public Cursor getSearchName(String dateFrom, String dateTo) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT  * FROM " + table + "WHERE DATE >=" + dateFrom + "AND DATE <=" + dateTo;
        Cursor c = db.rawQuery("select * from " + table + " where DATE >=? AND DATE <=?", new String[] {dateFrom, dateTo});
        return c;
    }


    public boolean updateData(int id, String date, String time, String sport, String teams,
                              String location, String email, String comment,
                              String prediction) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(column2, date);
        contentValues.put(column3, time);
        contentValues.put(column4, sport);
        contentValues.put(column5, teams);
        contentValues.put(column6, location);
        contentValues.put(column7, email);
        contentValues.put(column8, comment);
        contentValues.put(column9, prediction);
        db.update(table, contentValues, "ID = ?", new String[]{String.valueOf(id)});
        return true;
    }

    public Boolean updateScore(int id, String score) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(column10, score);
        db.update(table, contentValues, "ID = ?", new String[]{String.valueOf(id)});
        return true;
    }

    public Boolean deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + table + " WHERE ID =" + id);
        return true;
    }

    public Boolean deleteDataAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + table);
        return true;
    }
}

//https://www.youtube.com/watch?v=qS1E-Vrk60E