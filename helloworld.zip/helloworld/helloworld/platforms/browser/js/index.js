/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {

        console.log('Received Event: ' + id);
		alert("Device Ready");
		createDatabase();
    }
};

<script type="text/javascript" language="JavaScript" >
function AddRecord(form) {
 var cn = new ActiveXObject("ADODB.Connection");
        var strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = C:\\Users\\deepakgopal\\Desktop\\Testing\\Database3.mdb";
        cn.Open(strConn);
        var rs = new ActiveXObject("ADODB.Recordset");
        var SQL = "select count(*) from data";
        rs.Open(SQL, cn);
        alert(rs(0));
        rs.AddNew
        rs.Fields("VDI") = Request.Form("vdi");
        rs.Fields("Staff") = Request.Form("staff");
        rs.Update;   
        rs.Close();
        cn.Close(); 

}

</script>
/*
var db;

function createDatabase() {
	
	var request = window.indexedDB.open("library");
	
	request.onupgradeneeded = function() {
		db = request.result;
		
		var store = db.createObjectStore("books", {keyPath: "isbn"});
		var titleIndex = store.createIndex("by_title", "title", {unique:true});
		var authorIndex = store.createIndex("by_author", "author");
		
		store.put({title: "Quarry Memories", author: "Fred", isbn: 123456});
		store.put({title: "Quarry Memories", author: "Fred", isbn: 34232});
		store.put({title: "Bedrock Nights", author: "Barney", isbn: 234567});
	};
	

	request.onsuccess = function() {
		db = request.result;
			alert("Database created");
	};
	
	request.onerror = function(event) {
			alert("Error creating database: " + request.errorCode);
	};
}


function readBook() {
	var tx = db.transaction("books", "readonly");
	var store = tx.objectStore("books");
	var index = store.index("by_title");
	var bookTitle = document.getElementById("search").value;
	var request = index.get(bookTitle);
	request.onsuccess = function() {
		
		var matching = request.result;
		var result = document.getElementById("result");
		
		if(matching !== undefined) {
			result.innerHTML="<br/> Title: " + matching.title + ", Author: "
			+ matching.author + ", ISBN: " + matching.isbn;
		} else {
			result.innerHTML = "<br/>No Match found";
		}
	};
}

function readAllBooks() {
	var tx = db.transaction("books", "readonly");
	var store = tx.objectStore("books");
	var index = store.index("by_author");
	
	var author = document.getElementById("search").value;
	var request = index.OpenCursor(IDBKeyRange.only(author));
	
	document.getElementById("result").innerHTML = "<br />";
	
	request.onsuccess = function() {
		var cursor = request.result;
		
		if(cursor) {
			document.getElementById("result").innerHTML +="<br />Title: "
			+cursor.value.title + ", Author" + cursor.value.author + ", ISBN:" + cursor.value.isbn;
			cursor.continue();
		} else {
			document.getElementById("result").innerHTML += "<br /><br /> Finished loading books"
		}
	};	
}



function storeName() {
	var myName = document.getElementById("name").value;
	window.localStorage.setItem("name", myName);
	displayName();
	return false;
}

function displayName() {
	var result = document.getElementById("result");
	var myName = window.localStorage.getItem("name");
	
	if(myName != null){
		result.innerHTML = "Your name is " + myName;
	 } else {
		 result.innerHTML = "Your name has not been set yet";	
	 }
}
*/